# Gitlab py scripts
The code can be used to gather the list of GitHub groups/projects and the permissions of the users in those groups/projects. group/projects are saved in an Excel file.
It can also be used to do other things :)


# Requirements
Required modules

* gitlab
* re
* xlwt


# Run
Use the following command to run:

<code>python3 list-of-groups-members.py</code>


<code>python3 list-of-projects-members.py</code>

<code>python3 add-user-to-all-groups.py</code>
